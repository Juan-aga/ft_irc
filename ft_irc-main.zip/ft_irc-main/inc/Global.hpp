#ifndef GLOBAL_HPP
#define GLOBAL_HPP 

#include <Person.hpp>
#include <Socket.hpp>
#include <DefineMod.hpp>
#include <Error.hpp>

#endif
