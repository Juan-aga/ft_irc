#ifndef ERROR_HPP
#define ERROR_HPP

#include <DefineMod.hpp>

void    error(string msg);
void    checkSocket(int sock, string message);

#endif